TriggerPlayerEvent = function(name, source, ...)

    TriggerServerEvent("rage-reborn:PlayerEventHandler",name,source,...)

end

